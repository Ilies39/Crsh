# 1XBET Crash CF Capture (Update)
Capture the CF Value of 1XBET Crash game using Puppeteer

![Static Badge](https://img.shields.io/badge/Disclaimer%20on%20Gambling!!!-%23ff2a2a)

The following content involves references to gambling and betting activities. It is important to note that I do not participate in any gambling or betting activities. This script has been updated solely at the request of a friend. I am not responsible for any decisions made or actions taken based on this content. Gambling involves financial risk and can be addictive. Please gamble responsibly and seek help if you believe you may have a gambling problem.

- Script Title: 1XBET Crash CF Capture.
- Author: Kalana Sankalpa (@Anon LK), update by @yidirk

## How to use

- Change the 1XBET URL in "1xbet_crash_cf_capture.js" (if needed).
- Change the browser location in "launch.js".
- Change the headless value in "launch.js" to false to run the browser in background (if needed).
- Then Run:

```bash
  npm install
  node 1xbet_crash_cf_capture.js
```
- The values of L , F (Crash value) & TS will added to the data.csv and data.txt file.